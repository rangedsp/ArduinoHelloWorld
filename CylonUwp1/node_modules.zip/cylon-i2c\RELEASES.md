## Release History

Version 0.22.0 - Use Cylon 1.1.0

Version 0.21.3 - Internal refactors

Version 0.21.2 - Corrected another error in MPU6050 driver

Version 0.21.1 - Corrected error in MPU6050 driver

Version 0.21.0 - Compatibility with Cylon 1.0.0

Version 0.20.1 - Fixes for BMP180 and MPL115A2 devices.

Version 0.20.0 - Add LIDAR-Lite support

Version 0.19.0 - Compatibility with Cylon 0.22.0

Version 0.18.0 - Compatibility with Cylon 0.21.0

Version 0.17.0 - Compatibility with Cylon 0.20.0

Version 0.16.0 - Compatibility with Cylon 0.19.0

Version 0.15.0 - Bugfixes, add LSM9DS0 support

Version 0.14.0 - Compatibility with Cylon 0.18.0

Version 0.13.0 - Compatibility with Cylon 0.16.0

Version 0.12.1 - Add peerDependencies to package.json

Version 0.12.0 - Compatibility with Cylon 0.15.0

Version 0.11.0 - Compatibility with Cylon 0.14.0, remove node-namespace.

Version 0.10.1 - Added new diagrams, tests, examples and bpm6080 driver

Version 0.10.0 - Update to cylon 0.13.0, Tessel compatibility, support for MPU6050 and BMP180

Version 0.9.0 - Update to cylon 0.12.0

Version 0.8.0 - Update to cylon 0.11.0, migrated to pure JS

Version 0.7.0 - Update to cylon 0.10.0, add drivers for LCD & MPL115A2

Version 0.6.0 - Update to Cylon 0.9.0

Version 0.5.1 - Bug fixes and updated BlinkM driver with full command set

Version 0.5.0 - Update to Cylon 0.8.0

Version 0.4.0 - Update to Cylon 0.7.0

Version 0.3.0 - Add support for HMC6352 digial compass

Version 0.2.0 - Update to Cylon 0.5.0

Version 0.1.0 - Add support for BlinkM
