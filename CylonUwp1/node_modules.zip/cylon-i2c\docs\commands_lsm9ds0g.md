# Commands

## getGyro

Gets the value of Gyroscope.