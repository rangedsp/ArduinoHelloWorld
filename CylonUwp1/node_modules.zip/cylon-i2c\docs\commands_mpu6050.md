# Commands

## getAngularVelocity

Gets the value of the Angular Velocity

## getAcceleration

Gets the value of the Acceleration

## getMotionAndTemp

Gets the value of the Motion.